package com.example.texttospeechoffline

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.TextView
import java.util.Locale


class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private lateinit var textStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        textStatus = findViewById(R.id.textStatus)
        textStatus.text = "Inicializando el lector de voz..."

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val editText = findViewById<EditText>(R.id.editText)
        val buttonSpeak = findViewById<Button>(R.id.buttonSpeak)
        val buttonStop = findViewById<Button>(R.id.buttonStop)

        tts = TextToSpeech(this, this)

        buttonSpeak.setOnClickListener {
            val texto = editText.text.toString().trim()
            when {
                texto.isEmpty() -> {
                    Toast.makeText(
                        this,
                        "Escribe un texto primero",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                !ttsReady -> {
                    Toast.makeText(
                        this,
                        "El motor de voz todavía no está listo",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                else -> {
                    textStatus.text = "Leyendo texto..."

                    tts.speak(
                        texto,
                        TextToSpeech.QUEUE_FLUSH,
                        null,
                        "lectura"
                    )
                }
            }
        }

        buttonStop.setOnClickListener {
            if (ttsReady) {
                tts.stop()
                textStatus.text = "Lectura detenida"
            }

        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {

            val resultado = tts.setLanguage(Locale.forLanguageTag("es-MX"))

            ttsReady =
                resultado != TextToSpeech.LANG_MISSING_DATA &&
                        resultado != TextToSpeech.LANG_NOT_SUPPORTED

            if (ttsReady) {
                textStatus.text = "Voz lista"
            } else {
                textStatus.text = "Idioma no disponible"

                Toast.makeText(
                    this,
                    "No hay una voz compatible en español",
                    Toast.LENGTH_LONG
                ).show()
            }

        } else {
            ttsReady = false
            textStatus.text = "Error al iniciar el motor de voz"

            Toast.makeText(
                this,
                "No se pudo iniciar el motor de voz",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}

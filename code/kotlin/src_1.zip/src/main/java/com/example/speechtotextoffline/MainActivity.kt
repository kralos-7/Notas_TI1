package com.example.speechtotextoffline

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    // Motor de reconocimiento de voz
    private var speechRecognizer: SpeechRecognizer? = null

    // Componentes de la interfaz
    private lateinit var editTextResult: EditText
    private lateinit var buttonListen: Button
    private lateinit var buttonStop: Button
    private lateinit var buttonClear: Button
    private lateinit var textStatus: TextView

    // Indica si el reconocimiento está activo
    private var isListening = false

    // Solicitud del permiso del micrófono
    private val requestPermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->

            if (granted) {
                startListening()
            } else {
                textStatus.text = "Permiso del micrófono denegado"

                Toast.makeText(
                    this,
                    "Necesitas permitir el uso del micrófono",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Vincular los elementos XML con Kotlin
        editTextResult = findViewById(R.id.editTextResult)
        buttonListen = findViewById(R.id.buttonListen)
        buttonStop = findViewById(R.id.buttonStop)
        buttonClear = findViewById(R.id.buttonClear)
        textStatus = findViewById(R.id.textStatus)

        // Comprobar disponibilidad del reconocimiento local
        initializeSpeechRecognizer()

        // Botón para iniciar el reconocimiento
        buttonListen.setOnClickListener {
            checkMicrophonePermission()
        }

        // Botón para detener el reconocimiento
        buttonStop.setOnClickListener {
            stopListening()
        }

        // Botón para limpiar el texto
        buttonClear.setOnClickListener {
            editTextResult.text.clear()
            textStatus.text = "Texto eliminado"
        }
    }

    // Inicializar el reconocedor exclusivamente local
    private fun initializeSpeechRecognizer() {

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            textStatus.text = "Servicio de reconocimiento no disponible"
            buttonListen.isEnabled = false
            return
        }

        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            textStatus.text = "Reconocimiento sin conexión no disponible"
            buttonListen.isEnabled = false

            Toast.makeText(
                this,
                "El dispositivo no dispone de reconocimiento local",
                Toast.LENGTH_LONG
            ).show()

            return
        }

        // Crear reconocedor de voz en el dispositivo
        speechRecognizer =
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)

        // Configurar los eventos del reconocimiento
        speechRecognizer?.setRecognitionListener(
            object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    textStatus.text = "Escuchando... habla ahora"
                }

                override fun onBeginningOfSpeech() {
                    textStatus.text = "Reconociendo voz..."
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Nivel de intensidad del audio
                }

                override fun onBufferReceived(buffer: ByteArray?) {
                    // Datos de audio recibidos
                }

                override fun onEndOfSpeech() {
                    textStatus.text = "Procesando voz..."
                }

                override fun onError(error: Int) {
                    isListening = false
                    textStatus.text = getErrorMessage(error)
                }

                override fun onResults(results: Bundle?) {

                    isListening = false

                    val recognizedText =
                        results?.getStringArrayList(
                            SpeechRecognizer.RESULTS_RECOGNITION
                        )

                    if (!recognizedText.isNullOrEmpty()) {

                        val texto = recognizedText[0]

                        // Agregar el resultado al área de texto
                        val textoActual =
                            editTextResult.text.toString()

                        val nuevoTexto =
                            if (textoActual.isBlank()) {
                                texto
                            } else {
                                "$textoActual\n$texto"
                            }

                        editTextResult.setText(nuevoTexto)

                        textStatus.text = "Reconocimiento completado"

                    } else {
                        textStatus.text = "No se reconoció ningún texto"
                    }
                }

                override fun onPartialResults(
                    partialResults: Bundle?
                ) {
                    // Resultados parciales mientras se habla
                }

                override fun onEvent(
                    eventType: Int,
                    params: Bundle?
                ) {
                    // Eventos adicionales
                }
            }
        )

        textStatus.text = "Listo para escuchar"
    }

    // Comprobar permiso del micrófono
    private fun checkMicrophonePermission() {

        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {

                startListening()
            }

            else -> {
                requestPermission.launch(
                    Manifest.permission.RECORD_AUDIO
                )
            }
        }
    }

    // Iniciar reconocimiento de voz
    private fun startListening() {

        if (speechRecognizer == null) {
            textStatus.text = "Reconocedor local no disponible"
            return
        }

        // Configurar el reconocimiento
        val intent = Intent(
            RecognizerIntent.ACTION_RECOGNIZE_SPEECH
        ).apply {

            // Tipo de reconocimiento: voz libre
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )

            // Idioma español de México
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE,
                "es-MX"
            )

            // Habilitar resultados parciales
            putExtra(
                RecognizerIntent.EXTRA_PARTIAL_RESULTS,
                true
            )
        }

        try {
            speechRecognizer?.startListening(intent)
            isListening = true
            textStatus.text = "Iniciando reconocimiento..."

        } catch (e: Exception) {
            isListening = false
            textStatus.text = "No se pudo iniciar el reconocimiento"
        }
    }

    // Detener reconocimiento
    private fun stopListening() {

        if (isListening) {
            speechRecognizer?.cancel()
            isListening = false
            textStatus.text = "Reconocimiento detenido"
        }
    }

    // Traducir códigos de error a mensajes
    private fun getErrorMessage(error: Int): String {

        return when (error) {

            SpeechRecognizer.ERROR_AUDIO ->
                "Error al capturar el audio"

            SpeechRecognizer.ERROR_CLIENT ->
                "Error en el cliente de reconocimiento"

            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "Permiso del micrófono insuficiente"

            SpeechRecognizer.ERROR_NETWORK ->
                "Error de red o servicio"

            SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "Tiempo de espera agotado"

            SpeechRecognizer.ERROR_NO_MATCH ->
                "No se reconoció la voz"

            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                "El reconocedor está ocupado"

            SpeechRecognizer.ERROR_SERVER ->
                "Error del servicio de reconocimiento"

            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "No se detectó voz"

            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED ->
                "Idioma español no compatible"

            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
                "Modelo de español no disponible"

            else ->
                "Error de reconocimiento: $error"
        }
    }

    // Liberar recursos al cerrar la aplicación
    override fun onDestroy() {

        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null

        super.onDestroy()
    }
}